import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Button;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.TextField;

/**
 *  CheckBox Demo application
 */

public class OrderForm extends Application
{
    // Fields
    private RadioButton sizeMini, sizeRegular,sizeGiant, sizeWrap, sizeTub, whiteBread, roseBread, wheatBread, glutenFreeBread, onions,tomatoes, oliveOil, salt, mayo,
    bananaPeppers, jalapeno, lettuce, vinegar, oregano, noCheese, pickles, relish, mustard, extraMeat, bacon, extraCheese;

    Label totalLabel, sizeLabel, breadLabel, toppingsLabel, extraToppingsLabel, notesLabel,nameLabel,srLabel;

    private TextField nameField, srField;

    public static void main(String[] args)
    {
        // Launch the application.
        launch(args);
    }

    @Override
    public void start(Stage primaryStage)
    {
        // Create the CheckBoxes.
        sizeMini = new RadioButton("Mini - $5.60");
        sizeRegular = new RadioButton("Regular $6.70");
        sizeGiant = new RadioButton("Giant $12.70");
        sizeWrap = new RadioButton("Wrap $2.50");
        sizeTub = new RadioButton("Tub $3.50");
        whiteBread = new RadioButton("White Bread");
        roseBread = new RadioButton("Rosemary Parmesan Bread");
        wheatBread = new RadioButton("Wheat Bread");
        glutenFreeBread = new RadioButton("Gluten Free Bread($2.00)"); 
        onions = new RadioButton("Onions*");
        tomatoes = new RadioButton("Tomatoes*");
        oliveOil = new RadioButton("Olive Oil Blend*");
        salt = new RadioButton("Salt*");
        mayo = new RadioButton("Mayo");
        bananaPeppers = new RadioButton("Banana Peppers");
        jalapeno = new RadioButton("Jalapeno Peppers");
        lettuce = new RadioButton("Lettuce*");
        vinegar = new RadioButton("Red Wine Vinegar*");
        oregano = new RadioButton("Oregano*");
        noCheese = new RadioButton("No Cheese");
        pickles = new RadioButton("Dill Pickles");
        relish = new RadioButton("Cherry Pepper Relish");
        mustard = new RadioButton("Mustard");
        extraMeat = new RadioButton("Extra Meat ($1.75)");
        bacon = new RadioButton("Add Bacon($1.50)");
        extraCheese = new RadioButton("Extra Cheese($1.00)");

        ToggleGroup radioGroup = new ToggleGroup();
        sizeMini.setToggleGroup(radioGroup);
        sizeRegular.setToggleGroup(radioGroup);
        sizeGiant.setToggleGroup(radioGroup);
        sizeWrap.setToggleGroup(radioGroup);
        sizeTub.setToggleGroup(radioGroup);
        whiteBread.setToggleGroup(radioGroup);
        roseBread.setToggleGroup(radioGroup);
        wheatBread.setToggleGroup(radioGroup);
        glutenFreeBread.setToggleGroup(radioGroup);
        onions.setToggleGroup(radioGroup);
        tomatoes.setToggleGroup(radioGroup);
        oliveOil.setToggleGroup(radioGroup);
        salt.setToggleGroup(radioGroup);
        mayo.setToggleGroup(radioGroup);
        bananaPeppers.setToggleGroup(radioGroup);
        jalapeno.setToggleGroup(radioGroup);
        lettuce.setToggleGroup(radioGroup);
        vinegar.setToggleGroup(radioGroup);
        oregano.setToggleGroup(radioGroup);
        noCheese.setToggleGroup(radioGroup);
        pickles.setToggleGroup(radioGroup);
        relish.setToggleGroup(radioGroup);
        mustard.setToggleGroup(radioGroup);

        // Create the Button control.
        Button totalButton = new Button("Get Total");

        // Register the event handler.
        // totalButton.setOnAction(new TotalButtonHandler());

        // Create a Label for the total.
        totalLabel = new Label("$0.00");
        sizeLabel = new Label("SIZE");
        breadLabel = new Label("BREAD");
        toppingsLabel = new Label("TOPPINGS");
        extraToppingsLabel = new Label("EXTRA TOPPINGS");
        notesLabel = new Label("Notes");
        nameLabel = new Label("Name");
        srLabel = new Label("Special Requests");
        
        //Creates text field for name
        nameField = new TextField();
        srField = new TextField();
        
        // Put the size options in a VBox.
        VBox sizeBoxVBox = new VBox(15,sizeLabel,sizeMini, sizeRegular, sizeGiant, sizeWrap,sizeTub);

        // Put the bread options in a VBox.
        VBox breadBoxVBox = new VBox(15, breadLabel, whiteBread, roseBread, wheatBread, glutenFreeBread);

        // Put the toppings options in a VBox.
        VBox toppingsVBox = new VBox(15, toppingsLabel, onions, tomatoes, oliveOil, salt, mayo, 
                bananaPeppers, jalapeno, lettuce, vinegar, oregano, noCheese, 
                pickles, relish, mustard); 
        VBox extraToppingsVBox = new VBox(15, extraToppingsLabel, extraMeat,bacon, extraCheese);
        VBox nameVBox = new VBox(15, notesLabel, nameLabel, nameField, srLabel, srField);
        
        Image image = new Image("file:phc.jpg");

        ImageView imageView = new ImageView(image);

        // Create another VBox to use as the root node.
        VBox mainVBox = new VBox(15, sizeBoxVBox, breadBoxVBox, toppingsVBox, extraToppingsVBox, nameVBox, totalButton, totalLabel);

        // Set the main VBox's alignment to center.
        mainVBox.setAlignment(Pos.TOP_LEFT);

        // Set the main VBox's padding to 10 pixels.
        mainVBox.setPadding(new Insets(10, 10, 10, 10));

        //Sets the default window size
        mainVBox.setPrefSize(400,500);

        HBox hbox =  new HBox(10);
        hbox.setPadding(new Insets(20, 0, 0, 20));
        hbox.getChildren().setAll(sizeBoxVBox, imageView);

        // Create a Scene.
        Scene scene = new Scene(mainVBox);

        // Add the Scene to the Stage.
        primaryStage.setScene(scene);

        // Show the window.
        primaryStage.show();   
    }

    // public void setBackground(Color bgColor)
    // {

    // }

    /*
     * Event handler class for totalButton
     */

    class TotalButtonHandler implements EventHandler<ActionEvent>
    {
        @Override
        public void handle(ActionEvent event)
        {
            // Variable to hold the result
            double result = 0.00;

            // Add up the toppings.
            if (sizeMini.isSelected())
                result += 5.60;

            if (sizeRegular.isSelected())
                result += 6.70;

            if (sizeGiant.isSelected())
                result += 12.70;

            if (sizeWrap.isSelected())
                result += 6.70;

            if (sizeTub.isSelected())
                result += 6.70;

            // Display the results.
            totalLabel.setText(String.format("$%,.2f", result));
        }
    }
}